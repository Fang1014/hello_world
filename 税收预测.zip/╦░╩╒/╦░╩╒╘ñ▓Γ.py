#author:fangwei
#-*- coding：utf-8 -*-
import numpy as np
import  pandas as pd
from   sklearn.linear_model import  Lasso
from sklearn.svm import LinearSVR
from GM11 import GM11
import matplotlib.pyplot as plt
tax_data=pd.read_csv(r'D:\360安全浏览器下载\Python数据分析与应用\第8章\实训数据\income_tax.csv',engine='python')
#print(tax_data.head())
tax_data=tax_data.loc[:,tax_data.columns!='year']
#print(np.round(tax_data.corr(method='pearson'),4))####相关系数
lasso=Lasso(1000).fit(tax_data.loc[:,tax_data.columns!='y'],tax_data.loc[:,'y'])
print(np.round(lasso.coef_,4))
mask=np.round(lasso.coef_,4)!=0
new_data=tax_data.loc[:,mask]
feature=new_data.columns
#print(new_data)
new_data.index=range(2004,2016)
new_data.loc[2016]=None
new_data.loc[2017]=None

for i in feature:
    f=GM11(np.array(new_data.loc[range(2004,2016),i]))[0]
    #print(GM11(np.array(new_data.loc[range(2004,2016),i]))[-2],GM11(np.array(new_data.loc[range(2004,2016),i]))[-1])
    new_data.loc[2016,i]=f(len(new_data)-1)
    new_data.loc[2017,i]=f(len(new_data))

y=list(tax_data['y'])
y.extend([np.NAN,np.NAN])
new_data['y']=np.array(y).reshape(-1,1)
#print(new_data)
#new_data.to_csv(r'D:\360安全浏览器下载\Python数据分析与应用\第8章\实训数据\income_tax_processed.csv')
train_data=new_data.loc[range(2004,2016),:]
data_mean=train_data.mean()
data_std=train_data.std()
train_data=(train_data-data_mean)/data_std
x_data=train_data.loc[:,feature]
y_data=train_data.loc[:,'y']
svr=LinearSVR().fit(x_data,y_data)
x_pred=(new_data[feature]-data_mean[feature])/data_std[feature].as_matrix()
y_pred=svr.predict(x_pred)*data_std['y']+data_mean['y']
new_data['y_pred']=y_pred
print(new_data)
new_data.to_csv(r'D:\360安全浏览器下载\Python数据分析与应用\第8章\实训数据\income_tax_predict.csv')
p=plt.figure(figsize=(20,20),dpi=80)
p.add_subplot(2,1,1)
plt.plot(range(2004,2018),new_data['y'],'r-o')
p.add_subplot(2,1,2)
plt.plot(range(2004,2018),new_data['y_pred'],'b-s')
plt.savefig(r'D:\360安全浏览器下载\Python数据分析与应用\第8章\实训数据\income_tax_predict.png')
plt.show()
